//
//  ViewController.h
//  heartrrating
//
//  Created by Yogesh Patel on 06/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *btn_out;

- (IBAction)btn_act:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl;

@end


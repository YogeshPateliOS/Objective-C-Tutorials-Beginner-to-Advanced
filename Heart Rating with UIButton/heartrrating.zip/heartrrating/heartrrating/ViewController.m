//
//  ViewController.m
//  heartrrating
//
//  Created by Yogesh Patel on 06/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btn_act:(UIButton *)sender
{
    NSUInteger store=sender.tag;
    
    for (UIButton * btn in _btn_out)
    {
        if (btn.tag<=store)
        {
            [btn setTitle:@"♥︎" forState:UIControlStateNormal];
            self.lbl.text=[NSString stringWithFormat:@"%ld Heart",store];
        }
        else{
            [btn setTitle:@"♡" forState:UIControlStateNormal];
        }
    }
}
@end

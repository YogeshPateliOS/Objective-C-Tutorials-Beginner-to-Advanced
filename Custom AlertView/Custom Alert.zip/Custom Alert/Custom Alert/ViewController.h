//
//  ViewController.h
//  Custom Alert
//
//  Created by Yogesh Patel on 18/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)btn:(UIButton *)sender;
- (IBAction)btn4:(id)sender;

- (IBAction)btnalert2:(UIButton *)sender;
- (IBAction)btn3:(id)sender;
- (IBAction)btn5:(id)sender;
- (IBAction)btn6:(id)sender;
- (IBAction)btn10:(id)sender;
- (IBAction)btn8:(id)sender;
- (IBAction)btn9:(id)sender;
- (IBAction)btn16:(id)sender;
- (IBAction)btn19:(id)sender;

- (IBAction)btn7:(id)sender;
- (IBAction)btn12:(id)sender;
- (IBAction)btn13:(id)sender;
- (IBAction)btn17:(id)sender;

- (IBAction)btn14:(id)sender;
- (IBAction)btn11:(id)sender;
- (IBAction)btn15:(id)sender;
- (IBAction)btn18:(id)sender;







@end


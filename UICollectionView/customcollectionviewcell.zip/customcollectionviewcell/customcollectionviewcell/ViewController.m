//
//  ViewController.m
//  customcollectionviewcell
//
//  Created by Yogesh Patel on 01/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"
#import "secondViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _arrimg=[[NSMutableArray alloc]initWithObjects:@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png",@"apple.png", nil];
    // Do any additional setup after loading the view, typically from a nib.
}



- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _arrimg.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    UIImageView *image1=(UIImageView *)[cell viewWithTag:1];
    image1.image=[UIImage imageNamed:[_arrimg objectAtIndex:indexPath.row]];
    
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    secondViewController * sec=[self.storyboard instantiateViewControllerWithIdentifier:@"sec"];
    sec.strimg=[_arrimg objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:sec animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

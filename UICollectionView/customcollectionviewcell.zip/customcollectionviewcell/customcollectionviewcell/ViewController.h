//
//  ViewController.h
//  customcollectionviewcell
//
//  Created by Yogesh Patel on 01/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UICollectionViewDelegate, UICollectionViewDataSource>

@property(strong, nonatomic)NSMutableArray * arrimg;
@end


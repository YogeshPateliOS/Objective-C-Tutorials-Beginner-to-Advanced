//
//  ViewController.m
//  sidebar
//
//  Created by Yogesh Patel on 25/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"
#import "customcell.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
@interface ViewController ()
{
    BOOL isSideViewOpen;
}
@end

@implementation ViewController
@synthesize sidebar,sideview, arrdata;
- (void)viewDidLoad {
    [super viewDidLoad];
    sidebar.backgroundColor=[UIColor groupTableViewBackgroundColor];
    sideview.hidden=YES;
    isSideViewOpen=false;
    // Do any additional setup after loading the view, typically from a nib.
    customcell *cell=[[customcell alloc]init];  // Index Value = 0
    cell.strimg=@"name.png";
    cell.strlbl=@"Name";
    customcell *cell1=[[customcell alloc]init];  // Index Value = 1
    cell1.strimg=@"password.png";
    cell1.strlbl=@"Password";
    customcell * cell2=[[customcell alloc]init];
    cell2.strimg=@"email.png";
    cell2.strlbl=@"Email";
    customcell *cell3=[[customcell alloc]init];
    cell3.strimg=@"mobile.png";
    cell3.strlbl=@"Mobile";
    customcell * cell4=[[customcell alloc]init];
    cell4.strimg=@"qual.png";
    cell4.strlbl=@"Qualification";
    arrdata=[[NSMutableArray alloc]initWithObjects:cell,cell1,cell2,cell3,cell4, nil];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrdata.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:@"cell"];
    }
    customcell *maincell=[arrdata objectAtIndex:indexPath.row];
    UIImageView *img1=(UIImageView *)[cell viewWithTag:1];
    img1.image=[UIImage imageNamed:maincell.strimg];
    UILabel *lbl1=(UILabel *)[cell viewWithTag:2];
    lbl1.text=maincell.strlbl;
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) //Name Row Access  // Index Value = 0
    {
        SecondViewController *sec=[self.storyboard instantiateViewControllerWithIdentifier:@"sec"];
        [self.navigationController pushViewController:sec animated:YES];
    }
    else if (indexPath.row == 1) // Password Row Access // Index Value =1
    {
        ThirdViewController *thr=[self.storyboard instantiateViewControllerWithIdentifier:@"third"];
        [self.navigationController pushViewController:thr animated:YES];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnmenu:(id)sender
{
    sideview.hidden=NO;
    sidebar.hidden=NO;
    [self.view bringSubviewToFront:sideview];// Uiview uske upar bring sideview
    if (!isSideViewOpen)
    {
        isSideViewOpen=true;
        [sideview setFrame:CGRectMake(0,70,0,487)];
        [sidebar setFrame:CGRectMake(0,0,0,479)];
        [UIView beginAnimations:@"TableAnimation" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.2];
        [sideview setFrame:CGRectMake(0,70,293,487)];
        [sidebar setFrame:CGRectMake(0,0,285,479)];
        [UIView commitAnimations];
    }
    else
    {
        isSideViewOpen=false;
        sideview.hidden=YES;
        sidebar.hidden=YES;
        [sideview setFrame:CGRectMake(0,70,293,487)];
        [sidebar setFrame:CGRectMake(0,0,285,479)];
        [UIView beginAnimations:@"TableAnimation" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.2];
        [sideview setFrame:CGRectMake(0,70,0,487)];
        [sidebar setFrame:CGRectMake(0,0,0,479)];
        [UIView commitAnimations];
    }
    
}
@end

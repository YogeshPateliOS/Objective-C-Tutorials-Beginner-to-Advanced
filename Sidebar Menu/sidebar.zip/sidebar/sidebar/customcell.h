//
//  customcell.h
//  sidebar
//
//  Created by Yogesh Patel on 25/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface customcell : NSObject
@property(strong, nonatomic)NSString *strimg;
@property(strong, nonatomic)NSString *strlbl;
@end

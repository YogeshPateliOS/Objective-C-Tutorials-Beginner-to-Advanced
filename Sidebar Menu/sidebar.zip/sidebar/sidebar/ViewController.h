//
//  ViewController.h
//  sidebar
//
//  Created by Yogesh Patel on 25/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
- (IBAction)btnmenu:(id)sender;

@property (strong, nonatomic) IBOutlet UIView *sideview;
@property (strong, nonatomic) IBOutlet UITableView *sidebar;
@property(strong, nonatomic)NSMutableArray *arrdata;
@end


//
//  ViewController.h
//  scroll11
//
//  Created by Yogesh Patel on 23/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;


@end


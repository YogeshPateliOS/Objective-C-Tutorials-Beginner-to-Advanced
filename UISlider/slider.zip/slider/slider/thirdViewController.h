//
//  thirdViewController.h
//  slider
//
//  Created by Yogesh Patel on 14/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface thirdViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UIView *view3;
@property (weak, nonatomic) IBOutlet UITableView *table3;
- (IBAction)btn3:(UIButton *)sender;
@property(strong, nonatomic)NSMutableArray * arrdata3;

@end

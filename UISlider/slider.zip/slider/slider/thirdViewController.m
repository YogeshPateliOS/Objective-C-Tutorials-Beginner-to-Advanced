//
//  thirdViewController.m
//  slider
//
//  Created by Yogesh Patel on 14/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "thirdViewController.h"
#import "secondViewController.h"
@interface thirdViewController ()
{
    BOOL isSideViewOpen;
}

@end

@implementation thirdViewController
@synthesize view3, table3, arrdata3;

- (void)viewDidLoad {
    [super viewDidLoad];
    arrdata3=[[NSMutableArray alloc]initWithObjects:@"First",@"Second",@"First",@"Second",@"First",@"Second", nil];
    table3.backgroundColor=[UIColor groupTableViewBackgroundColor];
    isSideViewOpen=false;
    view3.hidden=YES;
    // Do any additional setup after loading the view.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrdata3.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{ NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    tableView.scrollEnabled = NO;
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.textLabel.text=[arrdata3 objectAtIndex:indexPath.row];
    }
    return cell;
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btn3:(UIButton *)sender
{
    
    view3.hidden=NO;
    table3.hidden=NO;
    self.view.backgroundColor=[UIColor groupTableViewBackgroundColor];
    if (!isSideViewOpen)
    {
        isSideViewOpen=true;
        [view3 setFrame:CGRectMake(319, 50, 1, 165)];
        [table3 setFrame:CGRectMake(202, 0, 1, 165)];
        [UIView beginAnimations:@"TabelAnimation" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.2];
        [view3 setFrame:CGRectMake(117, 50, 203, 165)];
        [table3 setFrame:CGRectMake(0, 0, 203, 165)];
        [UIView commitAnimations];
    }
    else
    {
        isSideViewOpen=false;
        
        view3.hidden=YES;
        table3.hidden=YES;
        [view3 setFrame:CGRectMake(117, 50, 203, 165)];
        [table3 setFrame:CGRectMake(0, 0, 203, 165)];
        [UIView beginAnimations:@"TabelAnimation" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.2];
        [view3 setFrame:CGRectMake(319, 50, 1, 165)];
        [table3 setFrame:CGRectMake(202, 0, 1, 165)];
        [UIView commitAnimations];
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
    {
        secondViewController *sec = [self.storyboard instantiateViewControllerWithIdentifier:@"sec"];
        [self.navigationController pushViewController:sec animated:YES];
        
        
    }
    else if(indexPath.row == 1)
    {
        secondViewController *sec = [self.storyboard instantiateViewControllerWithIdentifier:@"sec"];
        [self.navigationController pushViewController:sec animated:YES];
        
    }
    
}

@end

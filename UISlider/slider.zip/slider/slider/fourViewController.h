//
//  fourViewController.h
//  slider
//
//  Created by Yogesh Patel on 14/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface fourViewController : UIViewController
- (IBAction)btn:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnout;

@end

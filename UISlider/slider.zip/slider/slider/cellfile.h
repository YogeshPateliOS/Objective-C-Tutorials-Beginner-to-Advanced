//
//  cellfile.h
//  slider
//
//  Created by Yogesh Patel on 14/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface cellfile : NSObject

@property(strong, nonatomic)NSString * strimg;
@property(strong, nonatomic)NSString * strlbl;
@property(strong, nonatomic)NSString * big;
@end

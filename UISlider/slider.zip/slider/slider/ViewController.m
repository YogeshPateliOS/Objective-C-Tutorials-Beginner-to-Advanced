//
//  ViewController.m
//  slider
//
//  Created by Yogesh Patel on 14/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"
#import "fifthViewController.h"
#import "secondViewController.h"
#import "cellfile.h"

@interface ViewController ()
{
    BOOL isSideViewOpen;
}
@end

@implementation ViewController
@synthesize sildbar, view2, view1, arrdata, arrimg;

- (void)viewDidLoad {
    [super viewDidLoad];
    
     sildbar.backgroundColor=[UIColor grayColor];
    isSideViewOpen=false;
    view2.hidden=YES;
    cellfile * cell1 =[[cellfile alloc]init];
    cell1.strimg=@"name.png";
    cell1.strlbl=@"Name";
    
    cellfile * cell2 =[[cellfile alloc]init];
    cell2.strimg=@"email.png";
    cell2.strlbl=@"Email";
    cellfile * cell3 =[[cellfile alloc]init];
    cell3.strimg=@"mobile.png";
    cell3.strlbl=@"Mobile";
    cellfile * cell4 =[[cellfile alloc]init];
    cell4.strimg=@"password.png";
    cell4.strlbl=@"Password";
    cellfile * cell5 =[[cellfile alloc]init];
    cell5.strimg=@"qual.png";
    cell5.strlbl=@"Qualification";
    
    arrdata =[[NSMutableArray alloc]initWithObjects:cell1, cell2, cell3, cell4, cell5, nil];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrdata.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{ UITableViewCell * cell =[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil)
    {
        cell =[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cellfile * maincell= [arrdata objectAtIndex:indexPath.row];
    
    UIImageView * image1=(UIImageView *)[cell viewWithTag:1];
    image1.image=[UIImage imageNamed:maincell.strimg];
    
    UILabel * label4=(UILabel *)[cell viewWithTag:2];
    label4.text=maincell.strlbl;
    return cell;
  
}

- (IBAction)btn:(UIButton *)sender
{
    view2.hidden=NO;
    sildbar.hidden=NO;
    self.view.backgroundColor=[UIColor grayColor];
    if (!isSideViewOpen)
    {
        isSideViewOpen=true;
        [view2 setFrame:CGRectMake(0, 90, 0, 577)];
        [sildbar setFrame:CGRectMake(0, 0, 0, 577)];
        [UIView beginAnimations:@"TabelAnimation" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.2];
        [view2 setFrame:CGRectMake(0, 90, 250, 577)];
        [sildbar setFrame:CGRectMake(0, 0, 250, 577)];
        [UIView commitAnimations];
    }
    else
    {
        isSideViewOpen=false;
        
        view2.hidden=YES;
        sildbar.hidden=YES;
        [view2 setFrame:CGRectMake(0, 90, 250, 577)];
        [sildbar setFrame:CGRectMake(0, 0, 250, 577)];
        [UIView beginAnimations:@"TabelAnimation" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.2];
        [view2 setFrame:CGRectMake(0, 90, 0, 577)];
        [sildbar setFrame:CGRectMake(0, 0, 0, 577)];
        [UIView commitAnimations];
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
    {
        secondViewController * fifth
        = [self.storyboard instantiateViewControllerWithIdentifier:@"sec"];
        [self.navigationController pushViewController:fifth animated:YES];
        
        
    }
    else if(indexPath.row == 1)
    {
        fifthViewController *fifth1 = [self.storyboard instantiateViewControllerWithIdentifier:@"fif"];
        [self.navigationController pushViewController:fifth1 animated:YES];
        
    }
    
}

@end

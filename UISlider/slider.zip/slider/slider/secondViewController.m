//
//  secondViewController.m
//  slider
//
//  Created by Yogesh Patel on 14/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "secondViewController.h"
#import "ViewController.h"
#import "cellfile.h"

@interface secondViewController ()
{
    BOOL isSideViewOpen;
}
@end

@implementation secondViewController
@synthesize table, view2, arrdata1;

- (void)viewDidLoad {
    [super viewDidLoad];
    arrdata1=[[NSMutableArray alloc]initWithObjects:@"First",@"Second", nil];
    view2.backgroundColor=[UIColor groupTableViewBackgroundColor];
    isSideViewOpen=false;
    view2.hidden=YES;
    // Do any additional setup after loading the view.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrdata1.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{ NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.textLabel.text=[arrdata1 objectAtIndex:indexPath.row];
    }
    return cell;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btn1:(UIButton *)sender
{
    view2.hidden=NO;
    table.hidden=NO;
    self.view2.backgroundColor=[UIColor groupTableViewBackgroundColor];
    if (!isSideViewOpen)
    {
        isSideViewOpen=true;
        [view2 setFrame:CGRectMake(319, 76, 1, 492)];
        [table setFrame:CGRectMake(319, 0, 1, 492)];
        [UIView beginAnimations:@"TableAnimation" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.2];
        [view2 setFrame:CGRectMake(0, 76, 320, 492)];
        [table setFrame:CGRectMake(80, 0, 240, 492)];
        [UIView commitAnimations];
    }
    else
    {
        isSideViewOpen=false;
        view2.hidden=YES;
        table.hidden=YES;
        [view2 setFrame:CGRectMake(0, 76, 320, 492)];
        [table setFrame:CGRectMake(80, 0, 240, 492)];
        [UIView beginAnimations:@"TableAnimation" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.2];
        [view2 setFrame:CGRectMake(319, 76, 1, 492)];
        [table setFrame:CGRectMake(319, 0, 1, 492)];
        [UIView commitAnimations];
    }
}
@end

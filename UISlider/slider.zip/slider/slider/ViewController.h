//
//  ViewController.h
//  slider
//
//  Created by Yogesh Patel on 14/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UIView *view1;

@property(strong, nonatomic)NSMutableArray * arrimg;
- (IBAction)btn:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIView *view2;
@property(strong, nonatomic)NSMutableArray *arrdata;
@property (weak, nonatomic) IBOutlet UITableView *sildbar;
@end


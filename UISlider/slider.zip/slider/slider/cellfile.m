//
//  cellfile.m
//  slider
//
//  Created by Yogesh Patel on 14/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "cellfile.h"
#import "secondViewController.h"

@implementation cellfile
@synthesize strimg,strlbl,big;
@end

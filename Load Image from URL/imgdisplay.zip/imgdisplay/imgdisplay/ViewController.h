//
//  ViewController.h
//  imgdisplay
//
//  Created by Yogesh Patel on 19/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *img;
- (IBAction)btn:(id)sender;


@end


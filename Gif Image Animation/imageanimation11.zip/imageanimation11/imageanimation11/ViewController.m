//
//  ViewController.m
//  imageanimation11
//
//  Created by Yogesh Patel on 26/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize img;
- (void)viewDidLoad {
    [super viewDidLoad];
    img.animationImages=[[NSArray alloc]initWithObjects:
                         [UIImage imageNamed:@"1.gif"],
                         [UIImage imageNamed:@"2.gif"],
                         [UIImage imageNamed:@"3.gif"],
                         [UIImage imageNamed:@"4.gif"],
                         [UIImage imageNamed:@"5.gif"],
                         [UIImage imageNamed:@"6.gif"],
                         [UIImage imageNamed:@"7.gif"],
                         [UIImage imageNamed:@"8.gif"],
                         [UIImage imageNamed:@"9.gif"],
                         [UIImage imageNamed:@"10.gif"],
                         [UIImage imageNamed:@"11.gif"],
                         [UIImage imageNamed:@"12.gif"],
                         [UIImage imageNamed:@"13.gif"],
                         [UIImage imageNamed:@"14.gif"],
                         [UIImage imageNamed:@"15.gif"],
                         [UIImage imageNamed:@"16.gif"],
                         [UIImage imageNamed:@"17.gif"],
                         [UIImage imageNamed:@"18.gif"],
                         
                         
                          nil];
    [img setAnimationRepeatCount:0];
    img.animationDuration = 2;
    [img startAnimating];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

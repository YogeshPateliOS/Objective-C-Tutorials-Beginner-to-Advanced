//
//  ViewController.h
//  imageanimation11
//
//  Created by Yogesh Patel on 26/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *img;


@end


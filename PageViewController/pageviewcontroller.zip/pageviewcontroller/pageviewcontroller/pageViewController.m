//
//  pageViewController.m
//  pageviewcontroller
//
//  Created by Yogesh Patel on 03/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "pageViewController.h"
#import "ViewController.h"
@interface pageViewController ()
{
    NSArray * arrimg;
}
@end

@implementation pageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arrimg=[[NSArray alloc]initWithObjects:@"google.jpg",@"linkedin.jpg",@"twitter.png",@"facebook.png", nil];
    self.dataSource=self;
    ViewController * vc=(ViewController *)[self viewcontorllerAtIndex:0];
    NSArray * arr=[NSArray arrayWithObject:vc];
    [self setViewControllers:arr direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//Helper Method
-(UIViewController *)viewcontorllerAtIndex:(NSUInteger)index
{
    ViewController *view1=[self.storyboard instantiateViewControllerWithIdentifier:@"view"];
    view1.strimg=arrimg[index];//images count
    view1.valueindex=index;//index value throught count
    return view1;
}
-(UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    NSUInteger index=((ViewController *)viewController).valueindex;
    if (index == 0 || index == NSNotFound)
    {
        return nil;
    }
    index--;
    return [self viewcontorllerAtIndex:index];
}

-(UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    NSUInteger index=((ViewController *)viewController).valueindex;
    if (index == NSNotFound)
    {
        return nil;
    }
    index++;
    if (index == arrimg.count)
    {
        return nil;
    }
    return [self viewcontorllerAtIndex:index];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

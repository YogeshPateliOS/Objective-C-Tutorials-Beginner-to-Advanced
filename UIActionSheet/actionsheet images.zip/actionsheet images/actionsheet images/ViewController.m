//
//  ViewController.m
//  actionsheet images
//
//  Created by Yogesh Patel on 13/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize image1;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)//Photo Alpha index=0
    {
        if (image1.alpha==1.0f)
        {
            image1.alpha=0.5f;
        }
        else if (image1.alpha==0.5f)
        {
            image1.alpha=1.0f;
        }
    }
    if (buttonIndex == 1) {    //Hide Photo Index=1
        if (image1.hidden==NO)
        {
            image1.hidden=YES;
        }
        else if (image1.hidden==YES)
        {
            image1.hidden=NO;
        }
    }
}
- (IBAction)action:(id)sender
{
    
    UIActionSheet *action=[[UIActionSheet alloc]initWithTitle:@"Photo " delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Photo Alpha",@"Hide Photo", nil];
    [action showInView:self.view];
}
@end

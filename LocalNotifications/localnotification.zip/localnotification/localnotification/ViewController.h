//
//  ViewController.h
//  localnotification
//
//  Created by Yogesh Patel on 26/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UserNotifications/UserNotifications.h>
@interface ViewController : UIViewController

- (IBAction)btnln:(id)sender;

@end


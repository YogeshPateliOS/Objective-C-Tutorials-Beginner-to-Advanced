//
//  ViewController.m
//  localnotification
//
//  Created by Yogesh Patel on 26/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    BOOL isGrantedNotificationAccess;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    isGrantedNotificationAccess = false;
    UNUserNotificationCenter * center = [UNUserNotificationCenter currentNotificationCenter];
    UNAuthorizationOptions options = UNAuthorizationOptionAlert + UNAuthorizationOptionSound;
    [center requestAuthorizationWithOptions:options completionHandler:
     ^(BOOL granted, NSError * _Nullable error){
         isGrantedNotificationAccess = granted;
     }
     ];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnln:(id)sender
{
    if (isGrantedNotificationAccess)
    {
        UNUserNotificationCenter *center=[UNUserNotificationCenter currentNotificationCenter];
        UNMutableNotificationContent * mucontent = [[UNMutableNotificationContent alloc]init];
        mucontent.title=@"Yogesh Title";
        mucontent.subtitle=@"Yogesh SubTitle";
        mucontent.body=@"Yogesh Body";
        mucontent.sound=[UNNotificationSound defaultSound];
        
        UNTimeIntervalNotificationTrigger *trigger=[UNTimeIntervalNotificationTrigger triggerWithTimeInterval:3 repeats:NO];
        UNNotificationRequest * request = [UNNotificationRequest requestWithIdentifier:@"UYLocalNotification" content:mucontent trigger:trigger];
        [center addNotificationRequest:request withCompletionHandler:nil];
        
    }
}
@end

//
//  ViewController.m
//  jsondemo post
//
//  Created by Yogesh Patel on 08/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"
#import "webservice.h"
@interface ViewController ()
{
    NSString *mainstr;
}
@end

@implementation ViewController
@synthesize txtname,txtdob,txtmobile,txtaddress;
- (void)viewDidLoad {
    [super viewDidLoad];
    //[self requestdata];
}

- (IBAction)btnsave:(UIButton *)sender
{
    [self requestdata];
}

-(void)requestdata
{
    mainstr = [NSString stringWithFormat:@"http://localhost/webservice/Register.php"];
    NSString * dbstr = [NSString stringWithFormat:@"Name=%@&Mobile=%@&DOB=%@&Address=%@",txtname.text,txtmobile.text,txtdob.text,txtaddress.text];
    [webservice executequery:mainstr strpremeter:dbstr withblock:^(NSData * dbdata, NSError *error) {
        NSLog(@"Data: %@", dbdata);
        if (dbdata!=nil)
        {
            NSDictionary *maindic = [NSJSONSerialization JSONObjectWithData:dbdata options:NSJSONReadingAllowFragments error:nil];
            NSLog(@"Response Data: %@", maindic);
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  ViewController.h
//  jsondemo post
//
//  Created by Yogesh Patel on 08/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *txtname;
@property (strong, nonatomic) IBOutlet UITextField *txtmobile;
@property (strong, nonatomic) IBOutlet UITextField *txtdob;
@property (strong, nonatomic) IBOutlet UITextField *txtaddress;
- (IBAction)btnsave:(UIButton *)sender;






-(void)requestdata;




@end


//
//  main.m
//  dic2
//
//  Created by Yogesh Patel on 07/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
       
        NSMutableArray *arrkey=[[NSMutableArray alloc]initWithObjects:@"fname",@"lname",@"mobile_no",@"email_id",@"city", nil];
        
         NSMutableArray *arrvalue=[[NSMutableArray alloc]initWithObjects:@"Yogesh",@"Patel",@"9090009090",@"yogesh@gmail.com",@"ahmedabad", nil];
        
         NSMutableArray *arrvalue1=[[NSMutableArray alloc]initWithObjects:@"Parth",@"Patel",@"9090009090",@"yogesh@gmail.com",@"ahmedabad", nil];
        
         NSMutableArray *arrvalue2=[[NSMutableArray alloc]initWithObjects:@"Sagar",@"Patel",@"9090009090",@"yogesh@gmail.com",@"ahmedabad", nil];
        
        NSMutableDictionary * dic=[[NSMutableDictionary alloc]initWithObjects:arrvalue forKeys:arrkey];
        
        NSMutableDictionary * dic1=[[NSMutableDictionary alloc]initWithObjects:arrvalue1 forKeys:arrkey];
        
        NSMutableDictionary * dic2=[[NSMutableDictionary alloc]initWithObjects:arrvalue2 forKeys:arrkey];
        NSLog(@"%@", dic);
         NSLog(@"%@", dic1);
         NSLog(@"%@", dic2);
        
        NSMutableArray * array=[[NSMutableArray alloc]initWithObjects:dic,dic1,dic2, nil];
        NSLog(@"Array = %@", array);
        
    }
    return 0;
}

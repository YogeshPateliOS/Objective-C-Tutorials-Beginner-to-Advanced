//
//  ViewController.m
//  pickerview
//
//  Created by Yogesh Patel on 01/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize arrdata, arrdata1, txt1, txt2;
- (void)viewDidLoad {
    [super viewDidLoad];
    arrdata=[[NSMutableArray alloc]initWithObjects:@"AAAAAAA",@"BBBBBB",@"CCCCCC",@"DDDDDD",@"EEEEE",@"FFFFF", nil];
    arrdata1=[[NSMutableArray alloc]initWithObjects:@"111111",@"22222",@"33333",@"44444",@"5555",@"666666", nil];
    
    // Do any additional setup after loading the view, typically from a nib.
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (component==0)
    {
        return arrdata.count;
    }
    if (component==1)
    {
        return arrdata1.count;
    }
    return component;
   // return arrdata.count;
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component ==0)
    {
        return [arrdata objectAtIndex:row];
    }
    if (component==1)
    {
        return [arrdata1 objectAtIndex:row];
    }
    return 0;
   // return [arrdata objectAtIndex:row];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (component==0)
    {
        self.txt1.text=[arrdata objectAtIndex:row];
    }
    if (component==1)
    {
        self.txt2.text=[arrdata1 objectAtIndex:row];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

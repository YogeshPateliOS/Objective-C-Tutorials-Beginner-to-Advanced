//
//  fourViewController.h
//  UIlabel
//
//  Created by Yogesh Patel on 25/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface fourViewController : UIViewController

@end

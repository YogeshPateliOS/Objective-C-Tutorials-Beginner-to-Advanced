//
//  secondViewController.m
//  UIlabel
//
//  Created by Yogesh Patel on 22/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "secondViewController.h"

@interface secondViewController ()
@property(strong,nonatomic)NSArray * arr;
@end

@implementation secondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _arr=[[NSArray alloc]initWithObjects:@"Hello",@"Hii",@"Hey", nil];
    UITableView *tblView=[[UITableView alloc]initWithFrame:CGRectMake(0, 44, 375, 242) style:UITableViewStylePlain];
    tblView.delegate=self;
    tblView.dataSource=self;
    tblView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"21.jpg"]];
    tblView.allowsMultipleSelection=NO;
    tblView.allowsMultipleSelectionDuringEditing=NO;
    tblView.sectionFooterHeight=30;
    tblView.separatorColor=[UIColor blackColor];
    tblView.sectionHeaderHeight=30;
    
    tblView.autoresizingMask=UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
  //  [tblView reloadData];
    //    NSArray *arr = tblView.visibleCells;
    _arr=[[NSArray alloc]initWithObjects:@"32",@"32",@"32",@"32",@"32",@"32", nil];
   
    [self.view addSubview:tblView];
    
   
    // Do any additional setup after loading the view.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arr.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    tableView.scrollEnabled=YES;
   // tableView.separatorStyle=UITableViewCellStateDefaultMask;
    if (cell==nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"21.jpg"]];
    cell.textLabel.text=[_arr objectAtIndex:indexPath.row];
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

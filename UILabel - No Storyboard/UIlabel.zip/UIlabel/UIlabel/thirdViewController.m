//
//  thirdViewController.m
//  UIlabel
//
//  Created by Yogesh Patel on 25/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "thirdViewController.h"

@interface thirdViewController ()

@end

@implementation thirdViewController
@synthesize imageview, arrdata;
- (void)viewDidLoad {
    [super viewDidLoad];
    UIScrollView *scroll=[[UIScrollView alloc]init];
    scroll.frame=CGRectMake(0, 361, 375, 306);
   scroll.contentSize=CGSizeMake(400, 800);
   // scroll.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"21.jpg"]];
    //scroll.backgroundColor=[UIColor groupTableViewBackgroundColor];
    imageview = [[UIImageView alloc]initWithImage:
               [UIImage imageNamed:@"21.jpg"]];
   // arrdata=[[NSArray alloc]initWithObjects:@"34",@"23",@"21", nil];
    //[scroll addSubview:arrdata];
    [scroll addSubview:imageview];
    [self.view addSubview:scroll];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

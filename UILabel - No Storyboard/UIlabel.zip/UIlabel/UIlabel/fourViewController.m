//
//  fourViewController.m
//  UIlabel
//
//  Created by Yogesh Patel on 25/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "fourViewController.h"

@interface fourViewController ()

@end

@implementation fourViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIWebView *web=[[UIWebView alloc]initWithFrame:CGRectMake(0, 0, 320, 568)];
    web.delegate=self;
    web.backgroundColor=[UIColor grayColor];
    web.scalesPageToFit=YES;
    NSString *str=@"https://www.google.co.in";
    NSURL *url=[NSURL URLWithString:str];
   // NSURL *url=[[NSURL alloc]initFileURLWithPath:@"https://www.google.com"];
    NSURLRequest *urlrequest=[NSURLRequest requestWithURL:url];
    [web loadRequest:urlrequest];
    [self.view addSubview:web];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  ViewController.m
//  UIlabel
//
//  Created by Yogesh Patel on 20/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize str;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnlbl:(UIButton *)sender
{
    // Using Below Code U can Create Runtime Label put this code on viewdidload...
   UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(110, 82, 155, 64)];// For create label first create property
    label.text=@"Hello";//label text
    label.textColor=[UIColor blueColor];//label text colour
    label.font=[UIFont systemFontOfSize:25.0];//label text font size
    label.baselineAdjustment=UIBaselineAdjustmentAlignBaselines;//used for baseline
    // label.backgroundColor=[UIColor grayColor];
    label.textAlignment=NSTextAlignmentCenter;//we can change a position of label text there is a center | center, left, right three type
    [label.layer setCornerRadius:20.0];//Manage corner shape
    [label.layer setBorderWidth:1.0f]; // manage border width
    
    [label.layer setBorderColor:[UIColor blackColor].CGColor];// set border color
    label.userInteractionEnabled=YES;
    label.highlighted=YES;//highlighted means popup color highlight yes so is enable
    label.highlightedTextColor=[UIColor blackColor];//highlighted color
    label.autoresizingMask =UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin |UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin |UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
     [self.view addSubview:label];// for view its complusary write this code
}

- (IBAction)btntxt:(UIButton *)sender
{
    // Using Below Code U can Create Runtime text put this code on viewdidload...
    UITextField *text=[[UITextField alloc]initWithFrame:CGRectMake(16, 211, 343, 30)];//For create text first create property
    text.borderStyle=UITextBorderStyleRoundedRect;//text border style roundrect
    text.placeholder=@"Enter text";// for placeholder
    text.backgroundColor=[UIColor colorWithRed:0/256.0 green:84/256.0 blue:129/256.0 alpha:1];//text background color
    text.font=[UIFont fontWithName:@"optima" size:20];//text font size and font name
    text.textColor=[UIColor whiteColor];//for text color
  //text.delegate=self;
    text.textAlignment=NSTextAlignmentCenter;//we can change a position of  text there is a center | center, left, right three type
    text.keyboardType=UIKeyboardTypeEmailAddress;
    text.returnKeyType=UIReturnKeyDone;
      text.userInteractionEnabled=YES;
      text.tag = 10;
        text.hidden = NO;
    text.secureTextEntry=YES; //for password field
        text.spellCheckingType=UITextSpellCheckingTypeDefault;
    text.autoresizingMask = UIViewAutoresizingFlexibleRightMargin |
        UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
       
    [self.view addSubview:text];// for view its complusary write this code
    
}

- (IBAction)btnbtn:(UIButton *)sender
{
    // Using Below Code U can Create Runtime button put this code on viewdidload...
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeRoundedRect];//first we create a property for button and also set a buttton type
    // UIButton *btn=[[UIButton alloc]initWithFrame:CGRectMake(164, 232, 47, 46)];
    //  btn.backgroundColor=[UIColor colorWithRed:0/256.0 green:84/256.0 blue:129/256.0 alpha:1];
    [btn setFrame:CGRectMake(140, 289, 94, 30)];// set frame sixe
    //[btn setTitle:@"Click" forState:UIControlStateNormal];
    //btn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btn setTitle:@"Hey !" forState:UIControlStateNormal];//set button title means button name
    [btn setTitleColor:[UIColor groupTableViewBackgroundColor] forState:UIControlStateNormal];//set button name color
    [btn setBackgroundColor:[UIColor  colorWithRed:0/256.0 green:84/256.0 blue:129/256.0 alpha:1]];//button background color
    
    [self.view addSubview:btn];// for view its complusary write this code
}

- (IBAction)btnview:(UIButton *)sender
{
    // Using Below Code U can Create Runtime view put this code on viewdidload...
    UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, 446, 375, 221)];// first create a property for view and also set a frame
    view.backgroundColor=[UIColor clearColor];// for a background color
    [view setBounds:CGRectMake(0, 446, 375, 221)];// setbound is also known as a frame size
    [view.layer setCornerRadius:10.0];// for setup corner redius
    [view.layer setBorderWidth:1.0f];// set border width
    [view setBackgroundColor:[UIColor  colorWithRed:0/256.0 green:84/256.0 blue:129/256.0 alpha:1]];// we can set a background color in rgb property
    [view.layer setBorderColor:[UIColor blackColor].CGColor];// set a border color
    [self.view addSubview:view];//for view its complusary write this code
    
}
@end

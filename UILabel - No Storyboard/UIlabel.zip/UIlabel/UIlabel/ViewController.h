//
//  ViewController.h
//  UIlabel
//
//  Created by Yogesh Patel on 20/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)btnlbl:(UIButton *)sender;
- (IBAction)btntxt:(UIButton *)sender;
- (IBAction)btnbtn:(UIButton *)sender;
- (IBAction)btnview:(UIButton *)sender;

@property(strong, nonatomic)NSMutableString *str;
@end


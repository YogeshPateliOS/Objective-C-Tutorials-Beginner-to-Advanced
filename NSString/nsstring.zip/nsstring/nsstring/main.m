//
//  main.m
//  nsstring
//
//  Created by Yogesh Patel on 01/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        //imutable
        NSString *str=@"It is a string";
        str=@"it change";
        NSLog(@"%@", str);
        
        //mutable string
        
        NSMutableString * str1=[[NSMutableString alloc]initWithString:@"It is a mutable string"];
        [str1 appendString:@" Working"];
        [str1 insertString:@" imutable " atIndex:8];
        [str1 replaceCharactersInRange:NSMakeRange(9, 8) withString:@"Replace"];
        [str1 deleteCharactersInRange:NSMakeRange(9, 7)];
        NSLog(@"%@", str1);
        
        
    }
    return 0;
}

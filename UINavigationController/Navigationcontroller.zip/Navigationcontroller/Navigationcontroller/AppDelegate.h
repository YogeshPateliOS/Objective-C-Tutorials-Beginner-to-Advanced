//
//  AppDelegate.h
//  Navigationcontroller
//
//  Created by Yogesh Patel on 09/09/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


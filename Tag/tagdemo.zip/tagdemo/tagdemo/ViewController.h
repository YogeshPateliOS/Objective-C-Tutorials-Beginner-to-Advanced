//
//  ViewController.h
//  tagdemo
//
//  Created by Yogesh Patel on 21/10/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *outlbl;


@end


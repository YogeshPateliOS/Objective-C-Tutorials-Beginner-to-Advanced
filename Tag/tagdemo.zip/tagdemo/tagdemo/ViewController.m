//
//  ViewController.m
//  tagdemo
//
//  Created by Yogesh Patel on 21/10/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
    
    //Uibutton with tag 4
    
    UIButton *btn = (UIButton *)[self.view viewWithTag:4];
    [btn setTitle:@"Click Me!" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor groupTableViewBackgroundColor] forState:UIControlStateNormal];
    [btn setBackgroundColor:[UIColor lightGrayColor]];
    
    //addtarget button click method
    
    [btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];//Action
    
}
-(void)btnclick
{
    self.view.backgroundColor = [UIColor blackColor];
    _outlbl.textColor = [UIColor blueColor];
    _outlbl.text = @"Outlet label";
    
    //Uilabel with tag = 1
    UILabel *lbl = (UILabel *)[self.view viewWithTag:1];//tag value is 1
    lbl.text = @"Tag value label";
    lbl.textColor = [UIColor groupTableViewBackgroundColor];
    lbl.backgroundColor = [UIColor lightGrayColor];
    lbl.textAlignment = NSTextAlignmentCenter;
    lbl.shadowColor = [UIColor groupTableViewBackgroundColor];
    
    //textfield tag = 2
    
    UITextField *txt = (UITextField *)[self.view viewWithTag:2];//tag value is 2
    txt.placeholder = @"Enter UserName";
    txt.text = @"Yogesh Patel";
    txt.textColor = [UIColor groupTableViewBackgroundColor];
    txt.backgroundColor = [UIColor lightGrayColor];
    txt.clearButtonMode = UITextFieldViewModeWhileEditing;
    
    //uiimageview with tag 3
    UIImageView *img = (UIImageView *)[self.view viewWithTag:3];
    img.image = [UIImage imageNamed:@"12.png"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

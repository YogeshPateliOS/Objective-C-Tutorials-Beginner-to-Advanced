//
//  ViewController.m
//  imagesanimation
//
//  Created by Yogesh Patel on 13/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize image1;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)animation:(id)sender
{
    image1.animationImages=[[NSArray alloc]initWithObjects:
                            [UIImage imageNamed:@"31.png"],
                            [UIImage imageNamed:@"32.png"],
                            [UIImage imageNamed:@"31.png"],
                            [UIImage imageNamed:@"32.png"],
                            [UIImage imageNamed:@"31.png"],
                            [UIImage imageNamed:@"32.png"],
                            [UIImage imageNamed:@"31.png"],
                            [UIImage imageNamed:@"32.png"],
                            [UIImage imageNamed:@"31.png"],
                            [UIImage imageNamed:@"32.png"],
                            [UIImage imageNamed:@"31.png"],
                            [UIImage imageNamed:@"32.png"],
                            [UIImage imageNamed:@"31.png"],
                            [UIImage imageNamed:@"32.png"],
                            nil];
    
    [image1 setAnimationDuration:2];
    image1.animationDuration = 2.0;
    [image1 startAnimating];
}
@end

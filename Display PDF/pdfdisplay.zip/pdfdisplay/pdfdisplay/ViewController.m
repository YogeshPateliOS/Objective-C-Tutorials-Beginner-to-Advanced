//
//  ViewController.m
//  pdfdisplay
//
//  Created by Yogesh Patel on 12/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *strpath=[[NSBundle mainBundle]pathForResource:@"c++" ofType:@"pdf"];
    NSURL *url=[NSURL URLWithString:strpath];
    NSURLRequest *request=[NSURLRequest requestWithURL:url];
    [_webview loadRequest:request];
    [_webview setScalesPageToFit:YES];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  ViewController.h
//  alertview
//
//  Created by Yogesh Patel on 03/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIAlertViewDelegate>
- (IBAction)alert:(id)sender;


@end


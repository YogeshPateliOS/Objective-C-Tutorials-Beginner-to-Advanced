//
//  ViewController.m
//  alertview
//
//  Created by Yogesh Patel on 03/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)alert:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Yogesh" message:@"Hii" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"2 nd",@"3 rd", @"4 th" ,nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        //Cancel button perform
        NSLog(@"cancel");
    }
    else if (buttonIndex == 1)
    {
        //2 nd button
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.google.com"]];
    }
    else if (buttonIndex == 2)
    {
        //3 rd button
    }
    else if (buttonIndex == 3)
    {
        //4 th button
    }
}


@end

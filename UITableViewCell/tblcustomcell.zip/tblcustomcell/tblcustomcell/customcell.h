//
//  customcell.h
//  tblcustomcell
//
//  Created by Yogesh Patel on 01/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface customcell : NSObject
@property(strong, nonatomic)NSString * strimg;
@property(strong, nonatomic)NSString * strlbl1;
@property(strong, nonatomic)NSString * strlbl2;

@end

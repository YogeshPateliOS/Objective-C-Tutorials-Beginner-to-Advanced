//
//  ViewController.m
//  tblcustomcell
//
//  Created by Yogesh Patel on 01/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"
#import "customcell.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
 //   @“Sundar Pichai”, @“Jeff Weiner”, @“Jack Dorsey”, @“Mark Zuckerberg”, @“Susan Wojcicki”
    
   // @“Google”, @“Linkedin”, @“Twitter”, @“Facebook”, @“Youtube”
    customcell * cell1=[[customcell alloc]init];
    cell1.strimg=@"google.jpg";
    cell1.strlbl1=@"Sundar Pichai";
    cell1.strlbl2=@"Google";
    
    customcell *cell2=[[customcell alloc]init];
    cell2.strimg=@"linkedin.jpg";
    cell2.strlbl1=@"Jeff Weiner";
    cell2.strlbl2=@"Linkedin";
    
    customcell *cell3=[[customcell alloc]init];
    cell3.strimg=@"twitter.jpg";
    cell3.strlbl1=@"Jack Dorsey";
    cell3.strlbl2=@"Twitter";
    
    customcell *cell4=[[customcell alloc]init];
    cell4.strimg=@"facebook.jpg";
    cell4.strlbl1=@"Mark Zuckerberg";
    cell4.strlbl2=@"Facebook";
    
    customcell *cell5=[[customcell alloc]init];
    cell5.strimg=@"youtube.jpg";
    cell5.strlbl1=@"Susan Wojcicki";
    cell5.strlbl2=@"Youtube";
    
    _arrdata=[[NSMutableArray alloc]initWithObjects:cell1, cell2, cell3, cell4, cell5, nil];
    // Do any additional setup after loading the view, typically from a nib.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrdata.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    customcell *maincell=[_arrdata objectAtIndex:indexPath.row];
    UIImageView *image1=(UIImageView *)[cell viewWithTag:1];
    image1.image=[UIImage imageNamed:maincell.strimg];
    UILabel *lbl1=(UILabel *)[cell viewWithTag:2];
    lbl1.text=maincell.strlbl1;
    UILabel *lbl2=(UILabel *)[cell viewWithTag:3];
    lbl2.text=maincell.strlbl2;
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

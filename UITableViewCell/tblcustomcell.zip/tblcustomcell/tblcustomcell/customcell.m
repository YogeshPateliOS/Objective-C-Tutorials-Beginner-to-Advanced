//
//  customcell.m
//  tblcustomcell
//
//  Created by Yogesh Patel on 01/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "customcell.h"
#import "ViewController.h"
@implementation customcell
@synthesize strimg, strlbl1, strlbl2;
@end

//
//  AppDelegate.h
//  Expanding Cell Demo
//
//  Created by Yogesh Patel on 04/09/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


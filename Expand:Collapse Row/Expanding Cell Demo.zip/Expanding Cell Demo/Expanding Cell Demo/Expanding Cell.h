//
//  Expanding Cell.h
//  Expanding Cell Demo
//
//  Created by Yogesh Patel on 04/09/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Expanding_Cell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblrow;
@property (strong, nonatomic) IBOutlet UILabel *lblrowtitle;
@property (strong, nonatomic) IBOutlet UILabel *lblfruit;
@property (strong, nonatomic) IBOutlet UILabel *lblfruittitle;
@property (strong, nonatomic) IBOutlet UILabel *lblcal;
@property (strong, nonatomic) IBOutlet UILabel *lblcalcal;
@property (strong, nonatomic) IBOutlet UIButton *btnfruit;

@property (strong, nonatomic) IBOutlet UIButton *btnnumber;



@end

//
//  DetailViewController.h
//  Expanding Cell Demo
//
//  Created by Yogesh Patel on 04/09/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
- (IBAction)btngo:(id)sender;
@property (strong, nonatomic) IBOutlet UIImageView *imageview;
@property (strong, nonatomic) IBOutlet UILabel *lblnumber;

@property(strong,nonatomic)NSMutableArray *arrimg;
@property int isnumber;
@property int isfruit;
@property int selectedRow;

@end

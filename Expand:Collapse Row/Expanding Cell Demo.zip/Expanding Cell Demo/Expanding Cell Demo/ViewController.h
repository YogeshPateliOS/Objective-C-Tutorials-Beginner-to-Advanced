//
//  ViewController.h
//  Expanding Cell Demo
//
//  Created by Yogesh Patel on 04/09/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *tableview;

@property(strong, nonatomic)NSMutableArray *arrrow;

@property(strong, nonatomic)NSMutableArray *arrrowtitle;

@property(strong, nonatomic)NSMutableArray *arrfruit;

@property int selectedIndex;

@property(strong,nonatomic)UIButton *btnfruit;
@property(strong,nonatomic)UIButton *btnnumber;
@end


//
//  ViewController.m
//  Expanding Cell Demo
//
//  Created by Yogesh Patel on 04/09/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"
#import "Expanding Cell.h"
#import "DetailViewController.h"
@interface ViewController ()

@end

@implementation ViewController
@synthesize arrrow,arrfruit,arrrowtitle,tableview,selectedIndex,btnfruit,btnnumber;
- (void)viewDidLoad {
    [super viewDidLoad];
    selectedIndex = -1;
    arrrow=[[NSMutableArray alloc]init];
    for (int ii=1; ii<=8; ii++)
    {
        NSString *string=[[NSString alloc]initWithFormat:@"Row %i",ii ];
        [arrrow addObject:string];
        
    }
    
    arrrowtitle=[[NSMutableArray alloc]initWithObjects:@"First Row",@"Second Row",@"Third Row",@"Four Row",@"Five Row",@"Six Row",@"Sevan Row",@"Eight Row", nil];
    arrfruit=[[NSMutableArray alloc]initWithObjects:@"Apple",@"orange",@"Banana",@"Grape",@"Blueberry",@"Lemon",@"lime",@"Peach", nil];
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrrowtitle.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Expanding_Cell *cell = (Expanding_Cell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil)
    {
        NSArray *nib=[[NSBundle mainBundle]loadNibNamed:@"Expanding Cell" owner:self options:nil];
        cell=[nib objectAtIndex:0];
    }
    cell.lblrow.text=arrrow[indexPath.row];
    cell.lblrowtitle.text=arrrowtitle[indexPath.row];
    cell.lblfruittitle.text=arrfruit[indexPath.row];
    int cal = (indexPath.row + 1)*25;
    cell.lblcalcal.text=[NSString stringWithFormat:@"%i",cal];
    
    btnfruit=cell.btnfruit;
    btnnumber=cell.btnnumber;
    btnfruit.tag=indexPath.row;
    btnnumber.tag=indexPath.row;
    return cell;
    
    
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (selectedIndex == indexPath.row)
    {
        return 100;
    }
    else
    {
        return 44;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (selectedIndex == indexPath.row)
    {
        selectedIndex = -1;
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        return;
    }
    if (selectedIndex==-1)
    {
        NSIndexPath *prev = [NSIndexPath indexPathForRow:selectedIndex inSection:0];
        selectedIndex=indexPath.row;
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:prev] withRowAnimation:UITableViewRowAnimationFade];
    }
    selectedIndex=indexPath.row;
    [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [btnfruit addTarget:self action:@selector(fruitpressed) forControlEvents:UIControlEventTouchDown];
    [btnnumber addTarget:self action:@selector(numberpressed) forControlEvents:UIControlEventTouchDown];

}

-(void) fruitpressed
{
    DetailViewController *dec = [[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil];
    dec.selectedRow=btnfruit.tag;
    dec.isfruit=1;
    [self presentViewController:dec animated:YES completion:nil];
}
-(void)numberpressed
{
    DetailViewController *dec = [[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil];
    dec.selectedRow=btnnumber.tag;
    dec.isnumber=1;
    [self presentViewController:dec animated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

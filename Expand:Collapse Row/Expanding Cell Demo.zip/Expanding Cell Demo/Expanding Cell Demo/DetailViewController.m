//
//  DetailViewController.m
//  Expanding Cell Demo
//
//  Created by Yogesh Patel on 04/09/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize imageview,lblnumber,isfruit,isnumber,selectedRow,arrimg;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated
{
    if (isfruit == 1)
    {
        arrimg=[[NSMutableArray alloc]initWithObjects:@"Apple.jpg",@"Orange.jpg",@"Banana.jpg",@"Grape.jpg",@"Blueberry.jpg",@"Lemon.jpg",@"Lime.jpg",@"Peach.jpg", nil];
        UIImage *img = [UIImage imageNamed:[arrimg objectAtIndex:selectedRow]];
        imageview.image=img;
        isfruit =0;
        
    }
    if (isnumber == 1)
    {
        int cal=(selectedRow +1)*25;
        lblnumber.text=[NSString stringWithFormat:@"%i",cal];
        isnumber = 0;
        
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btngo:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end

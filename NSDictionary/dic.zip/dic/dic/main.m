//
//  main.m
//  dic
//
//  Created by Yogesh Patel on 01/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
       
        //imutable dictionary
        
        NSDictionary * dic =[[NSDictionary alloc]initWithObjectsAndKeys:
                             @"12", @"21",
                             @"23", @"32",
                             @"34", @"43",
                              nil];
        NSLog(@"%@", dic);
        
        //mutable dictionary
        
        
        NSMutableDictionary * dic1 =[[NSMutableDictionary alloc]initWithObjectsAndKeys:
                                     @"12", @"21",
                                     @"23", @"32",
                                     @"34", @"43",
                                     nil];
        [dic1 setObject:@"45" forKey:@"54"];
        [dic1 removeObjectForKey:@"21"];
        NSLog(@" Mul Dictionary = %@", dic1);
        
    }
    return 0;
}

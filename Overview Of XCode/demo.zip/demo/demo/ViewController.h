//
//  ViewController.h
//  demo
//
//  Created by Yogesh Patel on 29/07/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)login:(UIButton *)sender;


@end

